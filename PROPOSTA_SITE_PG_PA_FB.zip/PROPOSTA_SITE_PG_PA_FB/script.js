
    
    function calcularElementoPG(razao, posicao) {
        
        return Math.pow(razao, posicao - 1);
    }

    
    var razao = parseFloat(prompt("Digite a razão da Progressão Geométrica:"));
    var posicao = parseInt(prompt("Digite a posição do elemento desejado na PG:"));

    
    var elemento = calcularElementoPG(razao, posicao);

    
    if (!isNaN(elemento)) {
        document.write("O elemento na posição " + posicao + " da PG é: " + elemento);
    } else {
        alert("Por favor, insira valores válidos.");
    }
	
		//javascript PA

        function gerarPA(primeiroTermo, razao, posicaoFinal) {
            var pa = [primeiroTermo];
            for (var i = 1; i < posicaoFinal; i++) {
                var proximoTermo = pa[i - 1] + razao;
                pa.push(proximoTermo);
            }
            return pa;
        }

        var primeiroTermo = parseFloat(prompt("Digite o primeiro termo da PA:"));
        var razao = parseFloat(prompt("Digite a razão da PA:"));
        var posicaoFinal = parseInt(prompt("Digite a posição do termo final:"));

        var paGerada = gerarPA(primeiroTermo, razao, posicaoFinal);
        document.write("A progressão aritmética gerada é: " + paGerada);
		
		//javascript fibonacci
        function Fibonacci() {
            var termos = parseInt(document.getElementById("termos").value);
            var resultado = document.getElementById("resultado");

            var fibonacci = [1, 1];
            var i = 2;

            while (i < termos) {
                var termo = fibonacci[i - 1] + fibonacci[i - 1];
                fibonacci[i] = termo;
                i++;
            }

            var sequencia = "";
            for (var a = 0; a < fibonacci.length; a++) {
                sequencia += fibonacci[a];
                if (a !== fibonacci.length - 1) {
                    sequencia += ", ";
                }
            }

            resultado.textContent = "Sequência de Fibonacci: " + sequencia;
        }

    

